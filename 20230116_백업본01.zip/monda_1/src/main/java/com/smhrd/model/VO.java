package com.smhrd.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Getter
@NoArgsConstructor
public class VO {
// 코드차트 실행하기위해 쓰는 VO임
	private int count;
	private String codedate;
}
