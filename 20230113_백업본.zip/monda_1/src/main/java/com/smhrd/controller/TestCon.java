package com.smhrd.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;


public class TestCon extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = request.getServletContext().getRealPath("./images");
		System.out.println(path);
		
		// 3. 파일의 max size
		int maxSize = 10*1024*1024;
		
		// 4. 인코딩 방식
		String encoding = "UTF-8";
		
		// 5. 중복제거 -> 파일명 뒤에 숫자 붙여주는 객체 중복되면 자동으로 1 or 2 ... 붙여줌
		DefaultFileRenamePolicy rename = new DefaultFileRenamePolicy();
		
		// 파일 업로드 -> MultipartRequest -> cos.jar
		MultipartRequest multi = new MultipartRequest(request, path, maxSize, encoding, rename);
	}

}
